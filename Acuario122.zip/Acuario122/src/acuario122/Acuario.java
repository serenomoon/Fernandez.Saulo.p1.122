package acuario122;

import java.util.ArrayList;
import java.util.List;

public class Acuario {
    
    private String nombre;
    private List<Animal> animales;

    public Acuario() {
        animales = new ArrayList<>();
    }
    
    public Acuario(String nombre) {
        this();
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void agregarAnimal(Animal animal){
        try{
            esNulo(animal);
            animalExiste(animal);
            animales.add(animal);
        }catch(AnimalExistenteException ex){
            System.out.println(ex.getMessage());
        }catch(NullPointerException ex2){
            System.out.println(ex2.getMessage());
        }
    }
    
    private void animalExiste(Animal animal){
        for(Animal n: animales){
            if(n.equals(animal)){
                throw new AnimalExistenteException();
            }
        }
    }
    
    private void esNulo(Animal animal){
        if(animal == null){
            throw new IllegalArgumentException("Se dio un valor nulo");
        }
    }
    
    public void mostrarAnimales(){
        for(Animal animal: animales){
            System.out.println(animal);
        }
    }
    
    private boolean puedeNadar(Animal animal){
        return animal instanceof Nadador;
    }
    
    private boolean puedeBuscarAlimento(Animal animal){
        return animal instanceof BuscadorAlimento;
    }
    
    public void nadar(){
        for(Animal animal: animales){
            if(puedeNadar(animal)){
                Nadador aniNad = (Nadador) animal;
                aniNad.nadar();
            } else{
                System.out.println("El animal " + animal.getNombre() +  " no puede nadar D:");
            }
        }
    }
    
    public void buscarAlimento(){
        for(Animal animal: animales){
            if(puedeBuscarAlimento(animal)){
                BuscadorAlimento aniAli = (BuscadorAlimento) animal;
                aniAli.buscarAlimento();
            } else{
                System.out.println("El animal " + animal.getNombre() +  " no puede buscar alimento D:");
            }
        }
    }
    
    
    public List filtrarPorTipoAgua(TipoAgua tipo){
        List animalAgua = new ArrayList<Animal>();
        for(Animal animal: animales){
            if(animal.getTipoAgua() == tipo){
                animalAgua.add(animal);
                System.out.println(animal.toString());
            }
            
        }
        return animalAgua;
    }
    
    public void mostrarAnimalesPorTipo(String TipoAnimal){
        for(Animal animal: animales){
            if(animal.getClass().getSimpleName().equals(TipoAnimal)){
                System.out.println(animal.toString());
            }
        }
    }
    
}
