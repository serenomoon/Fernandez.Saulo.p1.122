package acuario122;

public class MamiferoMarino extends Animal implements Nadador, BuscadorAlimento {
    
    private int frecuenciaRespiratoria;

    public MamiferoMarino(int frecuenciaRespiratoria, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        this.frecuenciaRespiratoria = frecuenciaRespiratoria;
    }

    public int getFrecuenciaRespiratoria() {
        return frecuenciaRespiratoria;
    }

    @Override
    public void nadar() {
        System.out.println("El Mamifero "+ getNombre() + " esta nadando!!");
    }

    @Override
    public void buscarAlimento() {
        System.out.println("El Mamifero "+ getNombre() + " esta buscando alimento!!");
    }
    
    @Override
    public String toString() {
        String sbBase = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append(sbBase);
        sb.append(System.lineSeparator());
        sb.append("Frecuencia Respiratoria: ").append(this.getFrecuenciaRespiratoria()).append(" segundos.");
        sb.append(System.lineSeparator());
        return sb.toString();
    }
    
}
