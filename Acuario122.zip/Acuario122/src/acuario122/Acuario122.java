package acuario122;

public class Acuario122 {

    public static void main(String[] args) {
        
        Acuario acua1 = new Acuario("Hola Mundo Marino");
        
        Pez anim1 = new Pez(10, "Nemo", "Tropical", TipoAgua.DULCE);
        Pez anim2 = new Pez(15, "Lebiste", "Fria", TipoAgua.SALADA);
        
        //Repetido:
        Pez anim7 = new Pez(15, "Lebiste", "Fria", TipoAgua.SALADA);
        
        MamiferoMarino anim3 = new MamiferoMarino(10, "Delfin", "Tropical", TipoAgua.SALADA);
        MamiferoMarino anim4 = new MamiferoMarino(30, "Ballena Franca", "Fria", TipoAgua.SALADA);
        
        Crustaceo anim5 = new Crustaceo(10, "Langosta", "Tropical", TipoAgua.DULCE);
        Crustaceo anim6 = new Crustaceo(10, "Centolla", "Fria", TipoAgua.SALADA);
        
        acua1.agregarAnimal(anim1);
        acua1.agregarAnimal(anim2);
        acua1.agregarAnimal(anim3);
        //acua1.agregarAnimal(anim7);
        acua1.agregarAnimal(anim4);
        acua1.agregarAnimal(anim5);
        acua1.agregarAnimal(anim6);
        
        System.out.println("MUESTRO ANIMALES!!");
        acua1.mostrarAnimales();
        
        System.out.println("\nNADANDO!!");
        acua1.nadar();
        System.out.println("\nBUSCANDO ALIMENTO!!");
        acua1.buscarAlimento();
        
        System.out.println("\nFILTRO TIPO AGUA!!");
        acua1.filtrarPorTipoAgua(TipoAgua.DULCE);
        //Retorno Lista
        System.out.println("\nFILTRO TIPO AGUA MOSTRANDO RETURN LISTA!!");
        System.out.println(acua1.filtrarPorTipoAgua(TipoAgua.SALADA));
        
        System.out.println("\nFILTRO ANIMALES!!");
        acua1.mostrarAnimalesPorTipo("Pez");
    }
    
}
