package acuario122;

public abstract class Animal {
    
    private String nombre;
    private String habitat;
    private TipoAgua tipoAgua;

    public Animal(String nombre, String habitat, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.habitat = habitat;
        this.tipoAgua = tipoAgua;
    }

    public String getNombre() {
        return nombre;
    }
    
    public String getHabitat() {
        return habitat;
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || this.getClass() != obj.getClass()) return false;
        Animal na = (Animal) obj;
        return na.getNombre().equals(this.nombre) && na.getHabitat().equals(this.getHabitat());
    }
     
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre: ").append(this.nombre);
        sb.append(System.lineSeparator());
        sb.append("Habitat: ").append(this.getHabitat());
        sb.append(System.lineSeparator());
        sb.append("Tipo Agua: ").append(this.getTipoAgua());
        return sb.toString();
    }
    
    
    
}
