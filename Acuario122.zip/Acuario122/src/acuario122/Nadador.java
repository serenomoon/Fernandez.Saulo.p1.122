package acuario122;

public interface Nadador {
    
    void nadar();
    
}
