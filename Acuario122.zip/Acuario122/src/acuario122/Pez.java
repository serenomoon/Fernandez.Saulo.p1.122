package acuario122;

public class Pez extends Animal implements Nadador {
    
    private double longitudMaxima;

    public Pez(double longitudMaxima, String nombre, String habitat, TipoAgua tipoAgua) {
        super(nombre, habitat, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }

    public double getLongitudMaxima() {
        return longitudMaxima;
    }
    
    @Override
    public void nadar() {
        System.out.println("El Pez "+ getNombre() + " esta nadando!!");
    }

    @Override
    public String toString() {
        String sbBase = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append(sbBase);
        sb.append(System.lineSeparator());
        sb.append("Longitud Maxima: ").append(this.getLongitudMaxima()).append("cm");
        sb.append(System.lineSeparator());
        return sb.toString();
    }
    
    
    
}
